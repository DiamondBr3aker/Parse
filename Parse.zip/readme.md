# Parse
Speech to Text Website

This project is licensed under the terms of the GNU General Public License 3.0.
